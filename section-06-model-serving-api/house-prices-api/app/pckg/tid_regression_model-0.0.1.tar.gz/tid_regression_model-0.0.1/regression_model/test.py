from pydantic import BaseModel

class Test(BaseModel):

    a: str
    b: int

t = Test(
    a='string',
    b='1'
)

t.a
